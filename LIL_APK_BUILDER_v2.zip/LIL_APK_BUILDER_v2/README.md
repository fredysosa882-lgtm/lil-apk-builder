# LIL APK BUILDER v2 — compilador Android real (MVP autoalojado)

Esta versión incluye una web pública, API de compilación y proyecto Android WebView.
El servidor convierte el HTML enviado en `app-debug.apk` usando Android Gradle.

## Requisitos del servidor
- Linux x86_64 recomendado
- Docker + Docker Compose
- 4 GB RAM mínimo (8 GB recomendado)
- Puertos 3000 (API) y 8080 (web) disponibles

## Ejecutar
1. Descomprime el ZIP en un servidor Linux con Docker.
2. Entra en la carpeta `LIL_APK_BUILDER_v2`.
3. Ejecuta: `docker compose up --build -d`
4. Abre `http://IP-DEL-SERVIDOR:8080`.

Para producción, configura HTTPS con un proxy inverso (Caddy/Nginx), cambia `API_BASE` en `web/app.js` al dominio de la API y establece `ALLOWED_ORIGIN` en `.env`.

## Qué hace
- Recibe nombre y HTML.
- Genera un proyecto Android WebView individual.
- Compila con Gradle/Android SDK dentro del contenedor.
- Devuelve el APK debug instalable.

## Limitaciones y seguridad
- Es un MVP autoalojado, no un servicio ya publicado en Internet.
- La APK es de depuración (`debug`), no una APK de lanzamiento firmada para Google Play.
- Para publicar en Play Store hace falta configurar una clave de firma privada, protegerla y generar un build `release`.
- El compilador limita tamaño, concurrencia y tiempo. No expongas el puerto de la API directamente a Internet sin HTTPS, firewall y protección antiabuso.
- Este prototipo admite HTML/CSS/JavaScript local. Recursos remotos pueden requerir permisos/red y conexión.
- El nombre se limita a caracteres seguros. El identificador de paquete se genera automáticamente.
