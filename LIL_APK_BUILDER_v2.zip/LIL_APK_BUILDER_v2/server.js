const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');

const execFileAsync = promisify(execFile);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_HTML = Number(process.env.MAX_HTML_BYTES || 1048576);
const MAX_BUILDS = Math.max(1, Number(process.env.MAX_BUILDS || 1));
const BUILD_TIMEOUT = Number(process.env.BUILD_TIMEOUT_MS || 240000);
const ORIGIN = process.env.ALLOWED_ORIGIN || '*';
let activeBuilds = 0;

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use((req,res,next) => {
  res.setHeader('Access-Control-Allow-Origin', ORIGIN);
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: '1mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 5, standardHeaders: true, legacyHeaders: false }));

app.get('/health', (_req,res) => res.json({ ok:true, service:'LIL APK BUILDER', version:'2.0.0' }));

function safeAppName(value) {
  const s = String(value || 'Mi Aplicacion').replace(/[^\p{L}\p{N} _.-]/gu,'').trim().slice(0,32);
  return s || 'Mi Aplicacion';
}
function safePackage(name) {
  const base = name.normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .toLowerCase().replace(/[^a-z0-9]+/g,'.').replace(/^\.+|\.+$/g,'').slice(0,24) || 'miapp';
  return `com.lilbuilder.${base}.${crypto.randomBytes(3).toString('hex')}`;
}
function xmlEscape(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}
function writeProject(dir, name, html) {
  const template = path.join(__dirname,'android-template');
  fs.cpSync(template, dir, { recursive:true });
  fs.mkdirSync(path.join(dir,'app/src/main/assets'),{recursive:true});
  fs.writeFileSync(path.join(dir,'app/src/main/assets/index.html'), html, 'utf8');
  fs.writeFileSync(path.join(dir,'app/src/main/res/values/strings.xml'),
    `<?xml version="1.0" encoding="utf-8"?>\n<resources><string name="app_name">${xmlEscape(name)}</string></resources>`);
  const pkg = safePackage(name);
  const gradle = fs.readFileSync(path.join(dir,'app/build.gradle'), 'utf8')
    .replace('__APPLICATION_ID__',pkg);
  fs.writeFileSync(path.join(dir,'app/build.gradle'),gradle);
}
app.post('/api/build', async (req,res) => {
  const html = req.body && req.body.html;
  const name = safeAppName(req.body && req.body.name);
  if (typeof html !== 'string' || !html.trim()) return res.status(400).json({error:'Pega tu código HTML antes de generar.'});
  if (Buffer.byteLength(html,'utf8') > MAX_HTML) return res.status(413).json({error:'El HTML supera el límite de 1 MB.'});
  if (activeBuilds >= MAX_BUILDS) return res.status(429).json({error:'El compilador está ocupado. Inténtalo de nuevo en unos minutos.'});
  activeBuilds++;
  const work = fs.mkdtempSync(path.join(os.tmpdir(),'lil-build-'));
  try {
    const project = path.join(work,'project');
    writeProject(project,name,html);
    await execFileAsync('gradle',['--no-daemon','--stacktrace','assembleDebug'],{
      cwd:project, timeout:BUILD_TIMEOUT, maxBuffer:5*1024*1024, env:process.env
    });
    const apk = path.join(project,'app/build/outputs/apk/debug/app-debug.apk');
    if (!fs.existsSync(apk)) throw new Error('Gradle terminó sin producir el APK.');
    const filename = `${name.replace(/[^a-zA-Z0-9_-]/g,'_')}.apk`;
    res.setHeader('Content-Type','application/vnd.android.package-archive');
    res.setHeader('Content-Disposition',`attachment; filename="${filename}"`);
    res.setHeader('Content-Length',fs.statSync(apk).size);
    const stream = fs.createReadStream(apk);
    stream.pipe(res);
    let cleaned = false;
    const cleanup = () => { if (!cleaned) { cleaned = true; fs.rmSync(work,{recursive:true,force:true}); activeBuilds--; } };
    stream.on('close',cleanup);
    stream.on('error',cleanup);
  } catch (err) {
    fs.rmSync(work,{recursive:true,force:true});
    activeBuilds--;
    const detail = String(err.stderr || err.message || 'Error de compilación').slice(-1800);
    console.error('Build failed:',detail);
    if (!res.headersSent) res.status(500).json({error:'No se pudo compilar la APK. Revisa que el servidor tenga memoria suficiente e intenta de nuevo.', detail});
  }
});

app.listen(PORT,'0.0.0.0',()=>console.log(`LIL APK BUILDER API escuchando en ${PORT}`));
