// Si web y API usan dominios distintos, reemplaza esta dirección por https://tu-dominio-api
const API_BASE = `${location.protocol}//${location.hostname}:3000`;
const $ = id => document.getElementById(id);
const sample = `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:Arial;background:#101827;color:white;display:grid;place-items:center;min-height:100vh;text-align:center}h1{color:#20c978}button{background:#20c978;border:0;padding:12px 18px;border-radius:9px}</style></head><body><main><h1>¡Mi primera app!</h1><p>Esta aplicación fue creada con LIL APK BUILDER.</p><button onclick="alert('¡Funciona!')">Probar</button></main></body></html>`;
function preview(){ $('preview').srcdoc=$('html').value || '<body style="font-family:Arial;padding:20px">Tu vista previa aparecerá aquí.</body>'; $('appTitle').textContent=$('name').value||'Mi Aplicación'; }
$('html').addEventListener('input',preview); $('name').addEventListener('input',preview);
$('example').onclick=()=>{$('html').value=sample;preview();$('status').textContent='Ejemplo cargado.';};
$('clear').onclick=()=>{$('html').value='';preview();$('status').textContent='Editor limpio.';};
$('build').onclick=async()=>{
 const html=$('html').value.trim(), name=$('name').value.trim()||'Mi Aplicación';
 if(!html){$('status').textContent='Pega tu código HTML primero.';return;}
 const btn=$('build');btn.disabled=true;$('status').textContent='Compilando en el servidor. Puede tardar varios minutos...';
 try{
  const response=await fetch(API_BASE+'/api/build',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,html})});
  if(!response.ok){let msg='Error del servidor';try{const data=await response.json();msg=data.error||msg;}catch{}throw new Error(msg);}
  const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=(name.replace(/[^a-z0-9_-]/gi,'_')||'app')+'.apk';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  $('status').textContent='¡APK generada! Revisa tus descargas e instala el archivo en Android.';
 }catch(e){$('status').textContent='No se pudo generar: '+e.message+'. Comprueba que el servidor esté activo.';}
 finally{btn.disabled=false;}
};
preview();
